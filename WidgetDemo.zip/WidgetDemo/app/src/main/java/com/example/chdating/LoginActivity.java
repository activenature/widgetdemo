package com.example.chdating;

import android.app.Activity;

public class LoginActivity extends Activity {
}
